"""
Views for the NVR Surveillance System.

URL map:
  GET/POST  /                     → login_view
  GET/POST  /login/               → login_view
  GET       /logout/              → logout_view
  GET       /dashboard/           → dashboard_view
  POST      /nvr/connect/         → api_connect_nvr      (AJAX)
  POST      /nvr/save/            → api_save_nvr         (AJAX)
  DELETE    /nvr/delete/<id>/     → api_delete_nvr       (AJAX)
  DELETE    /camera/delete/<id>/  → api_delete_camera    (AJAX)
  GET       /api/nvrs/            → api_list_nvrs        (AJAX)
  GET       /api/cameras/<nvr_id>/→ api_list_cameras     (AJAX)
"""

import json
import logging

from django.conf import settings
from django.shortcuts import render, redirect, get_object_or_404
from django.http import JsonResponse
from django.views.decorators.http import require_http_methods
from django.views.decorators.csrf import csrf_exempt
from django.utils import timezone

from .models import NVR, Camera
from .services.nvr_service import connect_nvr, save_nvr_to_db, load_all_nvrs, get_nvr_json_list
from .utils.url_parser import validate_nvr_url

logger = logging.getLogger('core')

# ─────────────────────────────────────────────────────────────────────────────
# Auth helpers
# ─────────────────────────────────────────────────────────────────────────────
ADMIN_USER = getattr(settings, 'APP_ADMIN_USERNAME', 'admin')
ADMIN_PASS = getattr(settings, 'APP_ADMIN_PASSWORD', 'admin123')


def _is_authenticated(request) -> bool:
    return bool(request.session.get('authenticated'))


def require_auth(view_fn):
    """Simple session-based auth decorator."""
    def wrapper(request, *args, **kwargs):
        if not _is_authenticated(request):
            if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                return JsonResponse({'success': False, 'error': 'Session expired. Please log in.'}, status=401)
            return redirect('login')
        return view_fn(request, *args, **kwargs)
    wrapper.__name__ = view_fn.__name__
    return wrapper


def _json_body(request) -> dict:
    """Parse JSON body, returning {} on failure."""
    try:
        return json.loads(request.body)
    except Exception:
        return {}


def _ok(**kwargs) -> JsonResponse:
    return JsonResponse({'success': True, **kwargs})


def _err(msg: str, status: int = 400) -> JsonResponse:
    return JsonResponse({'success': False, 'error': msg}, status=status)


# ─────────────────────────────────────────────────────────────────────────────
# Auth views
# ─────────────────────────────────────────────────────────────────────────────
def login_view(request):
    """Login page (hardcoded credentials: admin / admin123)."""
    if _is_authenticated(request):
        return redirect('dashboard')

    error = None
    if request.method == 'POST':
        username = request.POST.get('username', '').strip()
        password = request.POST.get('password', '').strip()

        if username == ADMIN_USER and password == ADMIN_PASS:
            request.session.cycle_key()
            request.session['authenticated'] = True
            request.session['username']      = username
            logger.info(f"Login success: {username}")
            return redirect('dashboard')
        else:
            logger.warning(f"Failed login: username='{username}'")
            error = 'Invalid username or password. Please try again.'

    return render(request, 'login.html', {'error': error})


def logout_view(request):
    """Flush session and redirect to login."""
    request.session.flush()
    return redirect('login')


# ─────────────────────────────────────────────────────────────────────────────
# Dashboard
# ─────────────────────────────────────────────────────────────────────────────
@require_auth
def dashboard_view(request):
    """Main dashboard: sidebar NVR tree + camera grid."""
    nvrs     = load_all_nvrs()
    username = request.session.get('username', 'Admin')
    return render(request, 'dashboard.html', {
        'nvrs':     nvrs,
        'username': username,
    })


# ─────────────────────────────────────────────────────────────────────────────
# NVR API – connect
# ─────────────────────────────────────────────────────────────────────────────
@require_auth
@require_http_methods(['POST'])
def api_connect_nvr(request):
    """
    AJAX: Test-connect to an NVR, detect brand, fetch cameras.
    Does NOT save to DB – call api_save_nvr() to persist.
    """
    data     = _json_body(request)
    url      = data.get('url', '').strip()
    port     = data.get('port', '').strip() or None
    username = data.get('username', '').strip()
    password = data.get('password', '')

    if not url:
        return _err('URL is required.')
    if not username:
        return _err('Username is required.')

    errors = validate_nvr_url(url)
    if errors:
        return _err(errors[0])

    result = connect_nvr(url, port, username, password)

    if not result['success']:
        return _err(result.get('error') or 'Connection failed.')

    return _ok(
        brand        = result['brand'],
        base_url     = result['base_url'],
        cameras      = result['cameras'],
        camera_count = result['camera_count'],
    )


# ─────────────────────────────────────────────────────────────────────────────
# NVR API – save
# ─────────────────────────────────────────────────────────────────────────────
@require_auth
@require_http_methods(['POST'])
def api_save_nvr(request):
    """AJAX: Save NVR + cameras to database."""
    data = _json_body(request)

    location = data.get('location', '').strip()
    url      = data.get('url', '').strip()
    if not location:
        return _err('Location is required.')
    if not url:
        return _err('URL is required.')

    try:
        nvr, created, saved_cameras = save_nvr_to_db(data)
    except Exception as e:
        logger.exception("Error saving NVR")
        return _err(str(e))

    return _ok(
        nvr_id       = nvr.id,
        nvr_location = nvr.location,
        brand        = nvr.brand,
        created      = created,
        cameras      = [c.to_dict() for c in saved_cameras],
    )


# ─────────────────────────────────────────────────────────────────────────────
# NVR API – delete
# ─────────────────────────────────────────────────────────────────────────────
@require_auth
@require_http_methods(['DELETE'])
def api_delete_nvr(request, nvr_id: int):
    """AJAX: Delete an NVR and all its cameras."""
    nvr = get_object_or_404(NVR, id=nvr_id)
    name = nvr.location
    nvr.delete()
    logger.info(f"Deleted NVR id={nvr_id} location='{name}'")
    return _ok(message=f"NVR '{name}' deleted.")


# ─────────────────────────────────────────────────────────────────────────────
# Camera API – delete
# ─────────────────────────────────────────────────────────────────────────────
@require_auth
@require_http_methods(['DELETE'])
def api_delete_camera(request, camera_id: int):
    """AJAX: Delete a single camera."""
    cam  = get_object_or_404(Camera, id=camera_id)
    name = cam.name
    cam.delete()
    logger.info(f"Deleted camera id={camera_id} name='{name}'")
    return _ok(message=f"Camera '{name}' deleted.")


# ─────────────────────────────────────────────────────────────────────────────
# List APIs
# ─────────────────────────────────────────────────────────────────────────────
@require_auth
def api_list_nvrs(request):
    """AJAX: Return all NVRs with cameras as JSON."""
    return _ok(nvrs=get_nvr_json_list())


@require_auth
def api_list_cameras(request, nvr_id: int):
    """AJAX: Return cameras for a specific NVR."""
    nvr     = get_object_or_404(NVR, id=nvr_id)
    cameras = [c.to_dict() for c in nvr.cameras.filter(is_active=True)]
    return _ok(cameras=cameras, nvr_id=nvr_id, nvr_location=nvr.location)
