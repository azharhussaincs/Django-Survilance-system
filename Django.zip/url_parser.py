"""
URL parsing, normalization, brand detection, and validation utilities.
"""
import re
import logging
from urllib.parse import urlparse, urlunparse, quote, urlencode

logger = logging.getLogger('core')


# ─────────────────────────────────────────────────────────────────────────────
# Brand detection patterns
# ─────────────────────────────────────────────────────────────────────────────
BRAND_PATTERNS = {
    'hikvision': [
        r'/doc/page/preview\.asp',
        r'/doc/page/login\.asp',
        r'/ISAPI/',
        r'hikvision',
        r'/doc/page/',
    ],
    'cpplus': [
        r'#/index/preview',
        r'cpplus',
        r'cp-plus',
    ],
    'dahua': [
        r'/RPC2',
        r'dahua',
        r'/cgi-bin/configManager\.cgi',
    ],
    'generic': [
        r'/cgi-bin/main-cgi',
        r'/cgi-bin/',
    ],
}

# CP Plus also uses port 20443 as a signal
CPPLUS_PORTS = {20443}


def detect_brand(url: str, port: int = None) -> str:
    """
    Detect the NVR brand from the URL and optional port.

    Priority order: hikvision → cpplus → dahua → generic → unknown
    """
    url_lower = url.lower()

    # Check port-based detection first
    if port and int(port) in CPPLUS_PORTS:
        return 'cpplus'

    # Check parsed port in URL
    try:
        parsed = urlparse(url if url.startswith('http') else 'http://' + url)
        if parsed.port and parsed.port in CPPLUS_PORTS:
            return 'cpplus'
    except Exception:
        pass

    # Check URL patterns
    for brand, patterns in BRAND_PATTERNS.items():
        for pattern in patterns:
            if re.search(pattern, url_lower):
                return brand

    return 'unknown'


def parse_nvr_url(url: str, port=None) -> dict:
    """
    Parse and normalise an NVR URL. Returns a dict with:
      full_url   - scheme://host:port/path
      base_url   - scheme://host:port   (no path)
      hostname
      port       - int or None
      scheme     - 'http' or 'https'
      path
      is_valid   - bool
      error      - str or ''
    """
    url = url.strip()
    if not url:
        return _invalid('URL is empty.')

    # Add scheme if missing
    if not url.startswith(('http://', 'https://')):
        url = 'http://' + url

    try:
        p = urlparse(url)
        hostname = p.hostname
        if not hostname:
            return _invalid(f"Cannot parse hostname from: {url}")

        # Determine final port
        final_port = p.port
        if port:
            try:
                explicit_port = int(port)
                if not final_port:
                    final_port = explicit_port
            except (ValueError, TypeError):
                pass

        # Build netloc
        if final_port and final_port not in (80, 443):
            netloc = f"{hostname}:{final_port}"
        else:
            netloc = hostname

        path = p.path or '/'

        full_url = urlunparse((p.scheme, netloc, path, '', '', ''))
        base_url = urlunparse((p.scheme, netloc, '',   '', '', ''))

        return {
            'full_url':  full_url,
            'base_url':  base_url,
            'hostname':  hostname,
            'port':      final_port,
            'scheme':    p.scheme,
            'path':      path,
            'is_valid':  True,
            'error':     '',
        }

    except Exception as e:
        return _invalid(str(e))


def _invalid(error: str) -> dict:
    return {
        'full_url': '', 'base_url': '', 'hostname': None,
        'port': None, 'scheme': 'http', 'path': '/',
        'is_valid': False, 'error': error,
    }


def validate_nvr_url(url: str) -> list[str]:
    """Return a list of validation error strings (empty = valid)."""
    errors = []
    if not url or not url.strip():
        errors.append('URL cannot be empty.')
        return errors

    result = parse_nvr_url(url)
    if not result['is_valid']:
        errors.append(f"Invalid URL: {result['error']}")
    return errors


def encode_password(password: str) -> str:
    """URL-encode special characters in a password (e.g. @ → %40)."""
    return quote(str(password), safe='')


def build_auth_url(base_url: str, username: str, password: str) -> str:
    """Build a URL with embedded basic auth credentials."""
    password_enc = encode_password(password)
    p = urlparse(base_url)
    netloc = f"{username}:{password_enc}@{p.netloc}"
    return urlunparse((p.scheme, netloc, p.path, p.params, p.query, p.fragment))
