"""
Abstract base class that every NVR adapter must implement.
"""
import abc
import logging

logger = logging.getLogger('core')


class BaseAdapter(abc.ABC):
    """
    Abstract adapter. Subclass for each NVR brand.

    Contract:
      login()         → bool   (True = auth succeeded)
      fetch_cameras() → list[dict]
      preview_url()   → str
      detect(url)     → bool  (classmethod)
    """

    BRAND = 'unknown'

    def __init__(self, base_url: str, username: str, password: str):
        self.base_url  = base_url.rstrip('/')
        self.username  = username
        self.password  = password
        self.logged_in = False
        self._session  = None

    # ── Required interface ────────────────────────────────────────────────────
    @abc.abstractmethod
    def login(self) -> bool:
        """Authenticate against the NVR. Return True on success."""

    @abc.abstractmethod
    def fetch_cameras(self) -> list[dict]:
        """
        Return list of camera dicts:
          {name, camera_id, preview_path, channel}
        """

    @abc.abstractmethod
    def preview_url(self, channel: int = None) -> str:
        """Return the primary preview page URL for this NVR."""

    @classmethod
    @abc.abstractmethod
    def detect(cls, url: str) -> bool:
        """Return True if the URL looks like this brand."""

    # ── Shared helpers ────────────────────────────────────────────────────────
    def _default_cameras(self, count: int = 8) -> list[dict]:
        """Generate placeholder camera entries when real discovery fails."""
        return [
            {
                'name':         f"Channel {i}",
                'camera_id':    str(i),
                'preview_path': self.preview_url(),
                'channel':      i,
            }
            for i in range(1, count + 1)
        ]

    def _make_session(self):
        from ..utils.helpers import make_session
        if self._session is None:
            self._session = make_session()
        return self._session

    @property
    def session(self):
        return self._make_session()
