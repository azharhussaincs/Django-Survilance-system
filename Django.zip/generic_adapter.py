"""
Generic / fallback NVR adapter.

Tries every known auth method and login path in sequence.
Always returns something useful (defaults if needed).
"""
import logging
from bs4 import BeautifulSoup
from requests.auth import HTTPDigestAuth, HTTPBasicAuth

from .base_adapter import BaseAdapter
from ..utils.helpers import safe_get, safe_post

logger = logging.getLogger('core')


class GenericAdapter(BaseAdapter):

    BRAND = 'generic'

    LOGIN_PATHS = [
        '/login', '/cgi-bin/login.cgi', '/web/login',
        '/cgi-bin/main-cgi', '/index.html', '/login.html',
        '/login.asp', '/logon', '/',
    ]

    PREVIEW_PATHS = [
        '/cgi-bin/main-cgi', '/live', '/preview', '/monitor',
        '/video', '/stream', '/channel', '/', '/live/index.html',
    ]

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._preview_path = '/'

    # ── Detection ─────────────────────────────────────────────────────────────
    @classmethod
    def detect(cls, url: str) -> bool:
        """Generic always matches as fallback."""
        return True

    # ── Login ─────────────────────────────────────────────────────────────────
    def login(self) -> bool:
        """
        Order:
        1. Digest auth on each preview path
        2. Basic auth on each preview path
        3. Form-based POST on each login path
        """

        # 1. Digest auth
        for path in self.PREVIEW_PATHS:
            try:
                url  = f"{self.base_url}{path}"
                resp = safe_get(self.session, url,
                                auth=HTTPDigestAuth(self.username, self.password))
                if resp and resp.status_code == 200:
                    self._preview_path = path
                    self.logged_in = True
                    logger.info(f"[Generic] Digest auth OK at {url}")
                    return True
            except (TimeoutError, ConnectionError):
                raise
            except Exception:
                pass

        # 2. Basic auth
        for path in self.PREVIEW_PATHS:
            try:
                url  = f"{self.base_url}{path}"
                resp = safe_get(self.session, url,
                                auth=HTTPBasicAuth(self.username, self.password))
                if resp and resp.status_code == 200:
                    self._preview_path = path
                    self.logged_in = True
                    logger.info(f"[Generic] Basic auth OK at {url}")
                    return True
            except (TimeoutError, ConnectionError):
                raise
            except Exception:
                pass

        # 3. Form-based login
        for login_path in self.LOGIN_PATHS:
            try:
                login_url = f"{self.base_url}{login_path}"
                get_resp  = safe_get(self.session, login_url)
                if not get_resp or get_resp.status_code != 200:
                    continue

                # Try to detect form action
                soup = BeautifulSoup(get_resp.text, 'html.parser')
                form = soup.find('form')
                action_url = login_url
                if form and form.get('action'):
                    action = form['action'].strip()
                    if action.startswith('http'):
                        action_url = action
                    elif action:
                        action_url = f"{self.base_url}/{action.lstrip('/')}"

                resp = safe_post(self.session, action_url, data={
                    'username': self.username, 'user':     self.username,
                    'password': self.password, 'pass':     self.password,
                    'passwd':   self.password, 'pwd':      self.password,
                })
                if resp and resp.status_code in (200, 302):
                    self._preview_path = login_path
                    self.logged_in = True
                    logger.info(f"[Generic] Form login OK at {action_url}")
                    return True
            except (TimeoutError, ConnectionError):
                raise
            except Exception:
                pass

        # If everything fails, still mark as "connected" so the iframe can be shown
        logger.warning(f"[Generic] All auth methods failed for {self.base_url} – embedding anyway")
        self.logged_in = True
        return True

    # ── Camera discovery ──────────────────────────────────────────────────────
    def fetch_cameras(self) -> list[dict]:
        cameras = []
        for path in self.PREVIEW_PATHS:
            try:
                url  = f"{self.base_url}{path}"
                resp = safe_get(self.session, url)
                if not resp or resp.status_code != 200:
                    continue

                soup = BeautifulSoup(resp.text, 'html.parser')

                # Look for video/img/iframe/div elements hinting at cameras
                candidates = (
                    soup.find_all('video') +
                    soup.find_all('iframe') +
                    soup.find_all(attrs=lambda a: a and any(
                        k in str(a).lower() for k in
                        ['channel', 'cam', 'stream', 'live', 'preview', 'monitor']
                    ))
                )
                seen = set()
                for i, el in enumerate(candidates[:16]):
                    key = el.get('id') or el.get('src') or str(i)
                    if key in seen:
                        continue
                    seen.add(key)
                    name = (
                        el.get('title') or
                        el.get_text(strip=True) or
                        el.get('alt') or
                        f"Camera {len(cameras)+1}"
                    )
                    cameras.append({
                        'name':         str(name)[:60],
                        'camera_id':    str(i + 1),
                        'preview_path': path,
                        'channel':      len(cameras) + 1,
                    })

                if cameras:
                    self._preview_path = path
                    logger.info(f"[Generic] Discovered {len(cameras)} cameras at {path}")
                    return cameras

            except (TimeoutError, ConnectionError):
                raise
            except Exception as e:
                logger.debug(f"[Generic] Scrape failed at {path}: {e}")

        return self._default_cameras()

    # ── Preview URL ───────────────────────────────────────────────────────────
    def preview_url(self, channel: int = None) -> str:
        return f"{self.base_url}{self._preview_path}"
