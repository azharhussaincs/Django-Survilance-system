"""
Hikvision NVR adapter.

Detection: /doc/page/preview.asp  or  /doc/page/login.asp
Login:     Digest auth → Basic auth → Form-based login
Preview:   /doc/page/preview.asp
"""
import logging
from bs4 import BeautifulSoup
from requests.auth import HTTPDigestAuth, HTTPBasicAuth

from .base_adapter import BaseAdapter
from ..utils.helpers import safe_get, safe_post

logger = logging.getLogger('core')


class HikvisionAdapter(BaseAdapter):

    BRAND        = 'hikvision'
    LOGIN_PATH   = '/doc/page/login.asp'
    PREVIEW_PATH = '/doc/page/preview.asp'

    # ── Detection ─────────────────────────────────────────────────────────────
    @classmethod
    def detect(cls, url: str) -> bool:
        url_lower = url.lower()
        return any(p in url_lower for p in [
            '/doc/page/preview.asp',
            '/doc/page/login.asp',
            '/doc/page/',
            'hikvision',
        ])

    # ── Login ─────────────────────────────────────────────────────────────────
    def login(self) -> bool:
        """
        Try three methods in order:
        1. HTTP Digest Auth
        2. HTTP Basic Auth
        3. Form-based POST to login page
        """
        preview_url = f"{self.base_url}{self.PREVIEW_PATH}"

        # 1. Digest auth (most common for Hikvision)
        try:
            resp = safe_get(
                self.session, preview_url,
                auth=HTTPDigestAuth(self.username, self.password),
            )
            if resp and resp.status_code == 200 and 'login' not in resp.url.lower():
                self.logged_in = True
                logger.info(f"[Hikvision] Digest auth OK – {self.base_url}")
                return True
        except (TimeoutError, ConnectionError):
            raise
        except Exception as e:
            logger.debug(f"[Hikvision] Digest auth attempt failed: {e}")

        # 2. Basic auth
        try:
            resp = safe_get(
                self.session, preview_url,
                auth=HTTPBasicAuth(self.username, self.password),
            )
            if resp and resp.status_code == 200:
                self.logged_in = True
                logger.info(f"[Hikvision] Basic auth OK – {self.base_url}")
                return True
        except (TimeoutError, ConnectionError):
            raise
        except Exception as e:
            logger.debug(f"[Hikvision] Basic auth attempt failed: {e}")

        # 3. Form-based POST login
        try:
            login_url = f"{self.base_url}{self.LOGIN_PATH}"
            safe_get(self.session, login_url)   # GET first (for cookies / CSRF)

            # Encode password for special chars
            from ..utils.url_parser import encode_password
            resp = safe_post(self.session, login_url, data={
                'username': self.username,
                'password': encode_password(self.password),
                'encoded':  f"{self.username}:{encode_password(self.password)}",
            })
            if resp and resp.status_code in (200, 302):
                self.logged_in = True
                logger.info(f"[Hikvision] Form login OK – {self.base_url}")
                return True
        except (TimeoutError, ConnectionError):
            raise
        except Exception as e:
            logger.debug(f"[Hikvision] Form login failed: {e}")

        logger.warning(f"[Hikvision] All login methods failed for {self.base_url}")
        return False

    # ── Camera discovery ──────────────────────────────────────────────────────
    def fetch_cameras(self) -> list[dict]:
        cameras = []

        # First try the ISAPI channel list (returns XML/JSON)
        cameras = self._try_isapi()
        if cameras:
            return cameras

        # Fallback: scrape the preview page
        cameras = self._scrape_preview()
        if cameras:
            return cameras

        logger.warning(f"[Hikvision] Could not discover cameras – using defaults")
        return self._default_cameras()

    def _try_isapi(self) -> list[dict]:
        """Try to fetch channel list via Hikvision ISAPI."""
        cameras = []
        try:
            url  = f"{self.base_url}/ISAPI/System/Video/inputs/channels"
            resp = safe_get(self.session, url,
                            auth=HTTPDigestAuth(self.username, self.password))
            if not resp or resp.status_code != 200:
                return []
            soup = BeautifulSoup(resp.text, 'xml')
            for ch in soup.find_all('VideoInputChannel'):
                ch_id   = ch.find('id')
                ch_name = ch.find('name') or ch.find('channelName')
                idx = ch_id.get_text(strip=True) if ch_id else str(len(cameras) + 1)
                name = ch_name.get_text(strip=True) if ch_name else f"Channel {idx}"
                cameras.append({
                    'name':         name or f"Channel {idx}",
                    'camera_id':    idx,
                    'preview_path': self.PREVIEW_PATH,
                    'channel':      int(idx) if idx.isdigit() else len(cameras) + 1,
                })
        except Exception as e:
            logger.debug(f"[Hikvision] ISAPI fetch failed: {e}")
        return cameras

    def _scrape_preview(self) -> list[dict]:
        """Parse the preview page HTML for channel entries."""
        cameras = []
        try:
            url  = f"{self.base_url}{self.PREVIEW_PATH}"
            resp = safe_get(self.session, url,
                            auth=HTTPDigestAuth(self.username, self.password))
            if not resp or resp.status_code != 200:
                return []

            soup = BeautifulSoup(resp.text, 'html.parser')
            candidates = soup.find_all(
                attrs=lambda a: a and any(
                    k in str(a).lower() for k in ['channel', 'cam', 'stream', 'preview']
                )
            )
            for i, el in enumerate(candidates[:16]):
                name = el.get_text(strip=True) or f"Camera {i+1}"
                cameras.append({
                    'name':         name[:60],
                    'camera_id':    el.get('id') or el.get('data-ch') or str(i + 1),
                    'preview_path': self.PREVIEW_PATH,
                    'channel':      i + 1,
                })
        except Exception as e:
            logger.debug(f"[Hikvision] Preview scrape failed: {e}")
        return cameras

    # ── Preview URL ───────────────────────────────────────────────────────────
    def preview_url(self, channel: int = None) -> str:
        return f"{self.base_url}{self.PREVIEW_PATH}"
