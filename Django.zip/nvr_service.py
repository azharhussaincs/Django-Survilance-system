"""
NVR Service Layer – orchestrates brand detection, adapter selection,
login, camera fetching, and database persistence.
"""
import logging
from django.conf import settings
from django.utils import timezone

from ..adapters import HikvisionAdapter, CpPlusAdapter, DahuaAdapter, GenericAdapter
from ..utils.url_parser import detect_brand, parse_nvr_url

logger = logging.getLogger('core')

# Brand → Adapter mapping (order matters for detection priority)
ADAPTER_MAP = {
    'hikvision': HikvisionAdapter,
    'cpplus':    CpPlusAdapter,
    'dahua':     DahuaAdapter,
    'generic':   GenericAdapter,
    'unknown':   GenericAdapter,
}


def get_adapter(brand: str, base_url: str, username: str, password: str):
    """Instantiate the correct adapter for the given brand."""
    adapter_cls = ADAPTER_MAP.get(brand, GenericAdapter)
    logger.debug(f"Using adapter: {adapter_cls.__name__} for brand '{brand}'")
    return adapter_cls(base_url, username, password)


def connect_nvr(url: str, port, username: str, password: str) -> dict:
    """
    Full connection flow:
      1. Parse & validate URL
      2. Detect NVR brand
      3. Instantiate adapter
      4. Login
      5. Fetch cameras

    Returns:
      {
        success: bool,
        brand: str,
        base_url: str,
        cameras: list[dict],
        camera_count: int,
        error: str | None,
      }
    """
    result = {
        'success':      False,
        'brand':        'unknown',
        'base_url':     '',
        'cameras':      [],
        'camera_count': 0,
        'error':        None,
    }

    # ── 1. Parse URL ──────────────────────────────────────────────────────────
    parsed = parse_nvr_url(url, port)
    if not parsed['is_valid']:
        result['error'] = parsed.get('error') or f"Invalid URL: {url}"
        return result

    base_url = parsed['base_url']
    result['base_url'] = base_url

    # ── 2. Brand detection ────────────────────────────────────────────────────
    brand = detect_brand(url, parsed.get('port'))
    result['brand'] = brand
    logger.info(f"Detected brand '{brand}' for URL: {base_url}")

    # ── 3 + 4. Adapter + login ────────────────────────────────────────────────
    adapter = get_adapter(brand, base_url, username, password)
    try:
        ok = adapter.login()
        if not ok:
            result['error'] = "Login failed. Check credentials."
            return result
    except TimeoutError as e:
        result['error'] = f"Connection timed out: {e}"
        logger.error(result['error'])
        return result
    except ConnectionError as e:
        result['error'] = f"Cannot connect: {e}"
        logger.error(result['error'])
        return result
    except Exception as e:
        result['error'] = f"Login error: {e}"
        logger.exception("Unexpected login error")
        return result

    # ── 5. Fetch cameras ──────────────────────────────────────────────────────
    try:
        cameras = adapter.fetch_cameras()
        max_cams = getattr(settings, 'NVR_MAX_CAMERAS', 64)
        cameras = cameras[:max_cams]
        result['cameras']      = cameras
        result['camera_count'] = len(cameras)
        result['success']      = True
        logger.info(f"Fetched {len(cameras)} cameras from {base_url}")
    except Exception as e:
        result['error'] = f"Camera fetch error: {e}"
        logger.exception("Error fetching cameras")

    return result


def save_nvr_to_db(data: dict):
    """
    Persist an NVR and its cameras to the database.

    data keys: location, url, port, username, password, brand, cameras[]
    Returns: (nvr_instance, created_bool, saved_cameras_list)
    """
    from ..models import NVR, Camera

    parsed   = parse_nvr_url(data['url'], data.get('port'))
    base_url = parsed['base_url'] or data['url']

    nvr, created = NVR.objects.update_or_create(
        url=base_url,
        defaults={
            'location':      data.get('location', 'Unknown'),
            'port':          parsed.get('port'),
            'username':      data.get('username', ''),
            'password':      data.get('password', ''),
            'brand':         data.get('brand', 'unknown'),
            'is_connected':  True,
            'status':        'connected',
            'last_connected': timezone.now(),
            'error_message': '',
        }
    )

    saved = []
    for cam in data.get('cameras', []):
        camera_id = str(cam.get('camera_id', ''))
        if not camera_id:
            camera_id = str(cam.get('channel', len(saved) + 1))

        # Ensure unique camera_id within the NVR
        if not camera_id:
            camera_id = str(len(saved) + 1)

        camera, _ = Camera.objects.update_or_create(
            nvr=nvr,
            camera_id=camera_id,
            defaults={
                'name':         cam.get('name', f"Camera {camera_id}"),
                'preview_path': cam.get('preview_path', '/'),
                'channel':      cam.get('channel'),
                'is_active':    True,
            }
        )
        saved.append(camera)

    logger.info(f"Saved NVR '{nvr.location}' (id={nvr.id}, created={created}) with {len(saved)} cameras")
    return nvr, created, saved


def load_all_nvrs():
    """Return all NVRs prefetch-related cameras, ordered by creation date."""
    from ..models import NVR
    return NVR.objects.prefetch_related('cameras').all()


def get_nvr_json_list():
    """Return all NVRs and cameras as a serialisable list of dicts."""
    nvrs = load_all_nvrs()
    return [
        {
            'id':           nvr.id,
            'location':     nvr.location,
            'url':          nvr.url,
            'brand':        nvr.brand,
            'status':       nvr.status,
            'is_connected': nvr.is_connected,
            'cameras': [c.to_dict() for c in nvr.cameras.filter(is_active=True)],
        }
        for nvr in nvrs
    ]
